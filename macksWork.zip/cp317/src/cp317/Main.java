package cp317;

public class Main {
	
	public static final String MAIN = "https://statsapi.web.nhl.com";
	public static final String TEAMLINK = "/api/v1/teams/";
	
	public static void main(String[] args) {
		
		APICaller call = new APICaller(MAIN, TEAMLINK);
		Data_Collector[][] test = call.fillTeam();
		float[] nhlMatrix = {0.803f, -0.076f, -0.112f, 0.027f, 0.048f, 0.103f, 0.566f};
		Odds cal = new Odds(nhlMatrix);
		Sport teamA = test[0][0].search("toronto maple leafs");
		Sport teamB = test[0][0].search("New Jersey Devils");
		float[] dataA = teamA.getStats();
		float[] dataB = teamB.getStats();
		float[] odds = cal.getOdds(dataA, dataB);
		for(int i=0; i<odds.length;i++) {
			System.out.println(odds[i]);
		}
	}
	
}
