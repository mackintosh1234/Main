package cp317;

public class Sport {
	
	private String name;
	
	public Sport() {
		name = "";
	}
	
	public Sport(String a) {
		this.name = a;
	}
	
	public String get_name() {
		return this.name;
	}
	
	public void set_name(String a) {
		this.name = a;
	}
	
	public void print() {
		System.out.println(this.name);
	}
	
	//initiate methods in main class for runtime polymorphism 
	public void setCity(String n) {}
	public String getCity() {return "";}
	public void setArena(String a) {}
	public String getArena() {return "";}
	public void setTeam(String a) {}
	public String getTeam() {return "";}
	public void setPosition(String a) {}
	public String getPosition() {return "";}
	public void setStats(float[] a) {}
	public float[] getStats() {float[] a = new float[0]; return a;}
	
}
